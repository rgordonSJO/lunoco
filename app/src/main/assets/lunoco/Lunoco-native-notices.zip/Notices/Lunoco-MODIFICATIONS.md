# Lunoco modification notices

On 2026-11-22, the Lunoco contributors incorporated the tested Phase 38C development changes into the proposed 0.11.0 source based on public commit `6ac9002d67cec32b745d1a664ead28de65bdba24`. The incorporation date records this source preparation. Earlier modification history remains credited to its original authors.

The main changes cover floating Home navigation and focus restoration, browsing and detail screens, accelerated D-pad scrubbing and persistent Trickplay preview, source attribution in the app, and the official GitHub stable updater protocol. Modified application, build and test text files carry dated notices in this tree. Required upstream copyright statements, GPL text and third-party attribution remain in place.

[GPLv2](LICENSE) · [Third-party sources](THIRD_PARTY.md) · [Build instructions](BUILDING.md)
